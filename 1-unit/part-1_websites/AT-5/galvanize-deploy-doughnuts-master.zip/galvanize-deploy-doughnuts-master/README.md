## Galvanize Deploy Doughnuts

Galvanize Deploy Doughnuts consists of 3 drills for demonstrating publish full-stack applications.

## Standard

```
|- Develop software for public consumption
    |- Publish full-stack applications
```
