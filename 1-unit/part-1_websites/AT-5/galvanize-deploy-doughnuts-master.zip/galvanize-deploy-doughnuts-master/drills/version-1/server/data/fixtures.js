module.exports = {
  cake: [{
    id: 1,
    type: 'Piped Cake Doughnuts'
  },
  {
    id: 2,
    type: 'Rolled-Out Cake Doughnuts'
  },
  {
    id: 3,
    type: 'Crullers'
  },
  {
    id: 4,
    type: 'Cider doughnuts'
  },
  {
    id: 5,
    type: 'Old-Fashioned Doughnuts'
  }
  ]}
