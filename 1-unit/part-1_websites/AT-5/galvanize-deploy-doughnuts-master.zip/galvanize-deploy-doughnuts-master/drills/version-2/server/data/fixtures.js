module.exports = {
  yeast: [{
    id: 1,
    type: 'Glazed Doughnuts'
  },
  {
    id: 2,
    type: 'Twist Doughnuts'
  },
  {
    id: 3,
    type: 'Jelly Doughnuts'
  },
  {
    id: 4,
    type: 'Cream filled doughnuts'
  },
  {
    id: 5,
    type: 'Dutchie'
  }
  ]}
