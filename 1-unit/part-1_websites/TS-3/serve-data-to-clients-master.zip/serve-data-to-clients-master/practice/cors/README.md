## Instructions

This app works correctly, except it doesn't send the right CORS headers. Add them.
