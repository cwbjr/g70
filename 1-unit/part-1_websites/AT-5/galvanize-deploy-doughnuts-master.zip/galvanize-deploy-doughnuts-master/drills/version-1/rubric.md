- [ ] Client site is live at the link provided
- [ ] The client-side code includes a `GET` request to the server url 
- [ ] Server site is live at the link provided

