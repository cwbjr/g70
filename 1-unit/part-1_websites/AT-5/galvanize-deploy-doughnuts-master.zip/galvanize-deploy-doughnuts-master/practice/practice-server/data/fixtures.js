module.exports = {
  doughnuts: [{
    id: 1,
    type: 'Lemon Cream'
  },
  {
    id: 2,
    type: 'Cinnamon'
  },
  {
    id: 3,
    type: 'Vanilla Frosting with Sprinkles'
  },
  {
    id: 4,
    type: 'Powdered'
  },
  {
    id: 5,
    type: 'Boston Cream'
  }
  ]}
