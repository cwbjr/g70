## Instructions

This app works correctly, but is missing the single room route (and error handler). Add it back.
