module.exports = {
  holes: [{
    id: 1,
    type: 'Yeast Doughnut Holes'
  },
  {
    id: 2,
    type: 'Cake Doughnut Holes'
  },
  {
    id: 3,
    type: 'Glazed Doughnut Holes'
  },
  {
    id: 4,
    type: 'Filled Doughnut Holes'
  }
  ]}
