## Instructions

This app works correctly, but is missing a way to look up an individual record in the list. Add a function to do that, and use it to populate the `record` variable in the single room route.
