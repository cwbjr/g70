## Serve Data to Clients

In this assessment, you'll take a CSV and return it back to a client from a deployed server.

## Standard

```
|- Demonstrate proficiency with a back-end framework
    |- Serve data to clients
```
