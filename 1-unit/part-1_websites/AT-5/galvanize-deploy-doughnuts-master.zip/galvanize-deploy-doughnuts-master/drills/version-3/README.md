### Version-3

## Instructions:
_Server_
1. Using the command line, copy the server folder into a NEW project
1. Commit that project to github
1. Deploy the server to Heroku

_Client_
1.  Update the client/src/main.js to do a fetch request to the deployed server site
1.  Using the command line, deploy this client site to Firebase

<hr>
When you submit, please include the link to this repo. Include your deployed links below:

Copy and Paste the Deployed Client Link to this README
> your url here

Copy and Paste the Deployed Server Link to this README
> you url here
